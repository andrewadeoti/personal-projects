# comp20081_Project to create a cloud based file server from scratch


This is a project based in java that aims to make a clopud based file server with user authentication and limited terminal access
